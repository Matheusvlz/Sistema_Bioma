import React from 'react';
import styles from './style/UserList.module.css';
import { User } from './types/chat';

interface UserListProps {
  users: User[];
  onSelectUser: (user: User) => void;
  activeUserId: string | null;
}

export const UserList: React.FC<UserListProps> = ({ users, onSelectUser, activeUserId }) => {
  return (
    <ul className={styles.userList}>
      {users.map((user) => (
        <li
          key={user.id}
          className={`${styles.userItem} ${user.id === activeUserId ? styles.active : ''}`}
          onClick={() => onSelectUser(user)}
        >
          <img src={user.avatar} alt={user.name} className={styles.userAvatar} />
          <div className={styles.userInfo}>
            <span className={styles.userName}>{user.name}</span>
            {user.isOnline && <span className={styles.userStatusOnline}>Online</span>}
            {!user.isOnline && user.lastSeen && <span className={styles.userStatusOffline}>Visto {user.lastSeen.toLocaleTimeString()}</span>}
          </div>
          {user.isOnline && <div className={styles.onlineIndicator}></div>}
        </li>
      ))}
    </ul>
  );
};