import React, { useState } from 'react';
import styles from './style/ChatContainer.module.css';
import { UserList } from './UserList';
import { ChatHeader } from './ChatHeader';
import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { Message, User } from './types/chat';

export const ChatContainer: React.FC = () => {
  const [activeChatUser, setActiveChatUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]); // Messages for the active chat

  // Dummy data for users
  const users: User[] = [
    { id: 'u1', name: 'Alice Silva', avatar: 'https://i.pravatar.cc/150?img=1', isOnline: true },
    { id: 'u2', name: 'Bob Souza', avatar: 'https://i.pravatar.cc/150?img=2', isOnline: false, lastSeen: new Date(Date.now() - 60 * 1000) },
    { id: 'u3', name: 'Charlie Lima', avatar: 'https://i.pravatar.cc/150?img=3', isOnline: true },
    { id: 'u4', name: 'Diana Costa', avatar: 'https://i.pravatar.cc/150?img=4', isOnline: false, lastSeen: new Date(Date.now() - 5 * 60 * 1000) },
  ];

  // Dummy function to simulate sending a message
  const handleSendMessage = (text: string) => {
    if (text.trim() && activeChatUser) {
      const newMessage: Message = {
        id: String(messages.length + 1),
        senderId: 'me', // Assuming 'me' is the current user
        senderName: 'Você',
        text,
        timestamp: new Date(),
        isMine: true,
      };
      setMessages((prevMessages) => [...prevMessages, newMessage]);
    }
  };

  const handleUserSelect = (user: User) => {
    setActiveChatUser(user);
    // Simulate loading messages for the selected user
    if (user.id === 'u1') {
      setMessages([
        { id: 'm1', senderId: 'u1', senderName: 'Alice Silva', text: 'Olá! Como você está?', timestamp: new Date(Date.now() - 120000), isMine: false },
        { id: 'm2', senderId: 'me', senderName: 'Você', text: 'Estou bem, e você?', timestamp: new Date(Date.now() - 90000), isMine: true },
        { id: 'm3', senderId: 'u1', senderName: 'Alice Silva', text: 'Tudo ótimo por aqui! 😊', timestamp: new Date(Date.now() - 60000), isMine: false },
      ]);
    } else {
      setMessages([]); // Clear messages for other users
    }
  };

  return (
    <div className={styles.chatContainer}>
      <div className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <h3>Chats</h3>
        </div>
        <UserList users={users} onSelectUser={handleUserSelect} activeUserId={activeChatUser?.id || null} />
      </div>
      <div className={styles.mainChat}>
        {activeChatUser ? (
          <>
            <ChatHeader user={activeChatUser} />
            <MessageList messages={messages} />
            <MessageInput onSendMessage={handleSendMessage} />
          </>
        ) : (
          <div className={styles.noChatSelected}>
            Selecione um chat para começar a conversar
          </div>
        )}
      </div>
    </div>
  );
};