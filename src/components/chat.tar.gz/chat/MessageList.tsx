import React, { useEffect, useRef } from 'react';
import styles from './style/MessageList.module.css';
import { MessageItem } from './MessageItem';
import { Message } from './types/chat';

interface MessageListProps {
  messages: Message[];
}

export const MessageList: React.FC<MessageListProps> = ({ messages }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className={styles.messageList}>
      {messages.length === 0 ? (
        <div className={styles.noMessages}>Comece a conversar!</div>
      ) : (
        messages.map((message) => (
          <MessageItem key={message.id} message={message} />
        ))
      )}
      <div ref={messagesEndRef} /> {/* Empty div to scroll to */}
    </div>
  );
};