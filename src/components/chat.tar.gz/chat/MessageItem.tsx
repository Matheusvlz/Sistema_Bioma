import React from 'react';
import styles from './style/MessageList.module.css';
import { Message } from './types/chat';

interface MessageItemProps {
  message: Message;
}

export const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const messageClass = message.isMine ? styles.myMessage : styles.otherMessage;

  return (
    <div className={`${styles.messageBubbleContainer} ${messageClass}`}>
      <div className={styles.messageBubble}>
        <p className={styles.messageText}>{message.text}</p>
        <span className={styles.messageTime}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
};