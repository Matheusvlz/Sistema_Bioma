import React from 'react';
import styles from './style/ChatHeader.module.css';
import { User } from './types/chat';

interface ChatHeaderProps {
  user: User;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({ user }) => {
  return (
    <div className={styles.chatHeader}>
      <img src={user.avatar} alt={user.name} className={styles.avatar} />
      <div className={styles.userInfo}>
        <h3>{user.name}</h3>
        <span className={user.isOnline ? styles.online : styles.offline}>
          {user.isOnline ? 'Online' : `Visto por último: ${user.lastSeen?.toLocaleTimeString()}`}
        </span>
      </div>
      {/* Aqui você pode adicionar botões de ação, como chamada de vídeo, informações, etc. */}
    </div>
  );
};